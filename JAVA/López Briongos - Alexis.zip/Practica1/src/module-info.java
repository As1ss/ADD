/**
 * 
 */
/**
 * 
 */
module Practica1 {
}