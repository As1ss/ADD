package if05.practica1;

public class Constantes {
	static final int NUMCHARNOMBRE=20;
	static final int NUMCHARAPELLIDOS=30;
	static final int NUMCHARDNI=9;
	static final int NUMCHARCICLO=5;
	static final int TAMAÑONOMBRE = 40;
	static final int TAMAÑOAPELLIDOS = 60;
	static final int TAMAÑODNI = 18;
	static final int TAMAÑOCICLO = 10;
	static final int TAMAÑOCURSO = 4;
	static final int TAMAÑOREGISTRO = TAMAÑONOMBRE + TAMAÑOAPELLIDOS + TAMAÑODNI + TAMAÑOCICLO + TAMAÑOCURSO;
}
